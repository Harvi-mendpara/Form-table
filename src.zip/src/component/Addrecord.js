import { useState } from "react";
import { Button, Form } from "react-bootstrap";

export default function Addrecord({ tableData, onSubmit }) {

  // console.log('tableData----', tableData)
  const [record, setRecord] = useState({});


  console.log('record', record)

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setRecord({ ...record, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(e, record);
    setRecord();
  };
  return (
    <Form  onSubmit={handleSubmit}>
      {Array.isArray(tableData) &&
        tableData.map((item) => (
          <Form.Group >
            <Form.Label>{item}</Form.Label>
            <Form.Control
              type="text"
              name={item}
              value={record[item] || ""}
              onChange={handleInputChange}
            />
          </Form.Group>
        ))}
      <Button type="submit"
       
        variant="secondary"
        style={{ marginTop: "10px", width: "100px" }}>
        Submit
      </Button>
    </Form>
  );
}
